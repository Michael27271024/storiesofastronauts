/*
  audio-manager.js
  Simple, robust audio manager for the WebView-hosted game.
  - Looks for audio files under ./audio/ by filename (e.g. audio/menu_bgm.mp3)
  - Supports: playMusic(looping, fade), stopMusic(fade), playSfx(one-shot), global volumes, mute, and persistence of volumes.
  - Safe no-op behavior if files are missing or autoplay blocked.

  Usage (global):
    window.AM.init({ assets: { music: {...}, sfx: {...} }, defaultMusic: 'menu_bgm' });
    window.AM.playMusic('menu_bgm');
    window.AM.playSfx('jump');
    window.AM.setMusicVolume(0.7);
    window.AM.setSfxVolume(0.9);

  Note: Place your audio files in `app/src/main/assets/audio/` and use the filenames referenced below.
*/
(function(global){
  function safeGet(obj, key, fallback){ try { return obj[key]; } catch(e){ return fallback; } }

  class AudioWrapper {
    constructor(src, opts = {}){
      this.src = src;
      this.loop = !!opts.loop;
      this.element = new Audio();
      this.element.src = src;
      this.element.preload = 'auto';
      this.element.loop = this.loop;
      this.element.volume = safeGet(opts,'volume',1);
      this.isPlaying = false;
      this._fadeInterval = null;
    }
    play(){
      this.cancelFade();
      const p = this.element.play();
      if(p && p.then) p.then(()=>{ this.isPlaying = true; }).catch(()=>{ /* autoplay likely blocked, will play on user gesture */ });
    }
    pause(){ this.element.pause(); this.isPlaying = false; }
    stop(){ this.pause(); try{ this.element.currentTime = 0; }catch(e){} }
    setVolume(v){ this.element.volume = Math.max(0, Math.min(1, v)); }
    fadeTo(target, ms=400){
      this.cancelFade();
      const start = this.element.volume;
      const steps = Math.max(6, Math.floor(ms / 40));
      let i = 0;
      this._fadeInterval = setInterval(()=>{
        i++;
        const t = i / steps;
        const v = start + (target - start) * t;
        this.setVolume(v);
        if(i >= steps){ this.cancelFade(); if(target === 0) this.pause(); }
      }, Math.max(20, Math.floor(ms / steps)));
    }
    cancelFade(){ if(this._fadeInterval){ clearInterval(this._fadeInterval); this._fadeInterval = null; } }
  }

  class AudioManager {
    constructor(){
      this.music = {}; // name -> AudioWrapper
      this.sfx = {};
      this.currentMusic = null;
      // Force full-volume playback (no user controls)
      this.musicVolume = 1.0;
      this.sfxVolume = 1.0;
      this.preloadList = [];
      this.userGestureAttached = false;
      this._ensureUserGesture();
      // Preferences and mute controls intentionally removed per project settings
    }

    _ensureUserGesture(){
      // mobile webviews often allow programmatic audio; still, resume on first touch/click
      const resume = ()=>{ try{ for(const k in this.music) { const m = this.music[k]; if(m && !m.isPlaying && m.element.paused) { /* no-op */ } } }catch(e){} document.removeEventListener('touchstart', resume); document.removeEventListener('click', resume); };
      document.addEventListener('touchstart', resume, { once: true });
      document.addEventListener('click', resume, { once: true });
    }

  // Preferences storage removed - audio volume is fixed at maximum and cannot be changed

    init(opts = {}){
      // opts.assets: { music: {name: 'file.mp3', ...}, sfx: {name:'file.wav' }}
      const assets = opts.assets || {};
      const music = assets.music || {};
      const sfx = assets.sfx || {};
      for(const k in music){ this._createMusic(k, music[k]); }
      for(const k in sfx){ this._createSfx(k, sfx[k]); }
      // volumes are fixed at 1.0 (no-op setters)
      if(opts.autoplay && opts.defaultMusic) this.playMusic(opts.defaultMusic);
    }

    _createMusic(name, filename){
      try{
        const path = `audio/${filename}`;
        this.music[name] = new AudioWrapper(path, { loop: true, volume: this.musicVolume });
      }catch(e){ console.warn('audio:createMusic', e); }
    }

    _createSfx(name, filename){
      try{
        const path = `audio/${filename}`;
        this.sfx[name] = filename; // store filename, create element per-play for multiple overlapping
      }catch(e){ console.warn('audio:createSfx', e); }
    }

    playMusic(name, { fade = true, fadeMs = 400 } = {}){
  if(!this.music[name]) return;
      if(this.currentMusic === name) return; // already playing
      const next = this.music[name];
      if(this.currentMusic && this.music[this.currentMusic]){
        const prev = this.music[this.currentMusic];
        if(fade) prev.fadeTo(0, fadeMs); else prev.stop();
      }
      next.setVolume(0);
      next.element.loop = true;
      next.play();
      if(fade) next.fadeTo(this.musicVolume, fadeMs); else next.setVolume(this.musicVolume);
      this.currentMusic = name;
    }

    stopMusic({ fade = true, fadeMs = 400 } = {}){
      if(!this.currentMusic) return;
      const c = this.music[this.currentMusic];
      if(!c) return;
      if(fade) c.fadeTo(0, fadeMs); else c.stop();
      this.currentMusic = null;
    }

    playSfx(name){
      // play at fixed sfx volume
      const filename = this.sfx[name];
      if(!filename) return;
      try{
        const a = new Audio();
        a.src = `audio/${filename}`;
        a.preload = 'auto';
        a.volume = this.sfxVolume;
        // allow multiple overlapping effects
        const p = a.play();
        if(p && p.catch) p.catch(()=>{});
      }catch(e){ console.warn('audio:playSfx', e); }
    }
    // Volume setters are intentionally no-ops to keep audio at full volume
    setMusicVolume(v){ /* no-op - volumes are fixed at 1.0 */ }
    setSfxVolume(v){ /* no-op - volumes are fixed at 1.0 */ }
    toggleMute(){ /* no-op - mute disabled */ }
    isMuted(){ return false; }
  }

  // Export singleton
  const singleton = new AudioManager();
  global.AM = singleton;

})(window);
